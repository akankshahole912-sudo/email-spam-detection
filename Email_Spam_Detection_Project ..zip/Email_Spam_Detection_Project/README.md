# Email Spam Detection Using Machine Learning

## What's included
- `app.py`: Streamlit web application
- `requirements.txt`: Python libraries
- `data/spam.csv`: put your labelled dataset here (not included; download steps below)

## Dataset
This app supports common CSV layouts:
- `label,message`
- UCI SMS dataset columns `v1,v2`
- `category,text` or `class,email`

For a beginner-friendly labelled dataset, download the UCI SMS Spam Collection:
https://archive.ics.uci.edu/dataset/228/sms

If the downloaded file has no header and is tab-separated, open it in Excel and save as CSV with columns named `label` and `message`, or upload a correctly formatted CSV in the app sidebar.

Note: the UCI SMS collection is an SMS dataset, not a collection of full emails. It is appropriate for a text spam-classification demonstration. For an email-specific dataset, UCI Spambase contains engineered numeric features and requires a different pipeline.

## Run on Windows
1. Install Python 3.10–3.12 from https://www.python.org/downloads/ if needed. During installation, tick **Add Python to PATH**.
2. Extract the project ZIP.
3. Open the extracted `Email_Spam_Detection_Project` folder in VS Code.
4. Open Terminal > New Terminal.
5. Run:

   ```powershell
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1
   python -m pip install -r requirements.txt
   ```

   If PowerShell blocks activation, you can skip activation and run:
   `.\.venv\Scripts\python.exe -m pip install -r requirements.txt`
   and then:
   `.\.venv\Scripts\python.exe -m streamlit run app.py`

6. Download/prepare your labelled CSV and save it as `data\spam.csv`, OR upload the CSV using the app's sidebar.
7. Run:

   ```powershell
   python -m streamlit run app.py
   ```

8. Open the local address printed in the terminal (usually http://localhost:8501).

## Dataset CSV format
Example:
```csv
label,message
spam,"Congratulations, you won a prize!"
ham,"Please send me the lecture notes."
spam,"Claim your reward now."
ham,"The meeting starts at 10 AM."
```
Use many more labelled examples for useful results.

## Project methodology
1. Load labelled text data.
2. Clean missing/duplicate rows and normalize labels.
3. Split data into training (80%) and testing (20%) sets.
4. Convert text to numerical TF-IDF features.
5. Train a Multinomial Naive Bayes or Logistic Regression classifier.
6. Evaluate using accuracy, precision, recall, F1-score, and a confusion matrix.
7. Enter a message in the Streamlit interface to predict spam/not spam.

## Important
- This is a learning project, not a production security filter.
- Predictions depend on the dataset and may be wrong.
- Never use a model prediction alone to decide whether to open links or attachments.
