Place your labelled spam dataset here as spam.csv. Expected columns: label,message (or common alternatives such as v1,v2). See the main README.md for dataset download instructions.
